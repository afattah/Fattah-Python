expression = input("Enter an arithmetic expression: ")
print("Result:", eval(expression))