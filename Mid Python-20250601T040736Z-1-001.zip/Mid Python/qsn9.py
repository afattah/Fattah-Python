tuples = [(1, 'a'), (2, 'b')]
dictionary = dict(sorted(tuples))
print("Sorted dictionary:", dictionary)