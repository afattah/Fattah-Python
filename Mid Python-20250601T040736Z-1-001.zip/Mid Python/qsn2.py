var = input("Enter a variable: ")
print("Type of the variable:", type(eval(var)))