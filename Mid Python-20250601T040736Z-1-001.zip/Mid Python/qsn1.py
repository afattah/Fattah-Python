user_input = input("Enter a string: ")
print("Reversed string:", user_input[::-1])