import random

random_num = random.randint(1, 100)
attempts = 5
print("Guess the number (1-100):")

for i in range(attempts):
    guess = int(input(f"Attempt {i+1}: "))
    if guess == random_num:
        print("Correct! You guessed the number.")
        break
    elif guess < random_num:
        print("Too low.")
    else:
        print("Too high.")
else:
    print(f"Sorry, the number was {random_num}.")