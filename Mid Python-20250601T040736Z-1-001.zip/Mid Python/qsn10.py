input_file = "input.txt"
output_file = "output.txt"

with open(input_file, "r") as file:
    text = file.read()

word_freq = {}
for word in text.split():
    word_freq[word] = word_freq.get(word, 0) + 1

with open(output_file, "w") as file:
    for word, freq in sorted(word_freq.items()):
        file.write(f"{word}: {freq}\n")
print(f"Word frequencies saved to {output_file}.")