list1 = list(map(int, input("Enter first list (space-separated): ").split()))
list2 = list(map(int, input("Enter second list (space-separated): ").split()))

print("Union:", set(list1) | set(list2))
print("Intersection:", set(list1) & set(list2))
print("Symmetric Difference:", set(list1) ^ set(list2))